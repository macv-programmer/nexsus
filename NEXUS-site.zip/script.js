const missions = [
  {id:1,cat:"tech",tag:"TECNOLOGIA",title:"Código Fantasma",desc:"Encontre e corrija 5 falhas em um pequeno sistema JavaScript.",diff:"★★★★☆",xp:850,time:"45 MIN",icon:"⌘"},
  {id:2,cat:"games",tag:"GAMES",title:"Speedrun Relâmpago",desc:"Complete uma fase de um jogo à sua escolha no menor tempo possível.",diff:"★★★☆☆",xp:600,time:"1 HORA",icon:"◈"},
  {id:3,cat:"knowledge",tag:"CONHECIMENTO",title:"Mente em Expansão",desc:"Resolva um quiz de 20 perguntas sobre ciência e tecnologia.",diff:"★★★☆☆",xp:500,time:"30 MIN",icon:"✦"},
  {id:4,cat:"creative",tag:"CRIATIVIDADE",title:"Visão do Futuro",desc:"Crie um conceito visual de como você imagina uma cidade em 2050.",diff:"★★★★☆",xp:900,time:"2 HORAS",icon:"✎"},
  {id:5,cat:"sport",tag:"ESPORTES",title:"Zona de Energia",desc:"Faça uma atividade física segura e registre sua evolução no desafio.",diff:"★★☆☆☆",xp:350,time:"30 MIN",icon:"⚡"},
  {id:6,cat:"tech",tag:"TECNOLOGIA",title:"Arquiteto Digital",desc:"Desenhe a estrutura de uma página web para resolver um problema real.",diff:"★★★★★",xp:1200,time:"3 HORAS",icon:"◇"},
  {id:7,cat:"knowledge",tag:"CONHECIMENTO",title:"Código Secreto",desc:"Decifre uma sequência de enigmas lógicos e descubra a mensagem final.",diff:"★★★★☆",xp:750,time:"40 MIN",icon:"◉"},
  {id:8,cat:"creative",tag:"CRIATIVIDADE",title:"1 Ideia, 10 Minutos",desc:"Crie uma história curta a partir de três palavras sorteadas.",diff:"★★☆☆☆",xp:300,time:"10 MIN",icon:"✦"}
];

const leaders = [
  ["01","ShadowX","98.450 XP","SX"],["02","ZeroOne","91.200 XP","ZO"],["03","NeoBR","87.650 XP","NB"],
  ["04","Phantom","82.100 XP","PH"],["05","Ranger","8.450 XP","R"]
];

let state = JSON.parse(localStorage.getItem("nexusState") || '{"xp":8450,"completed":24,"streak":5}');
const grid = document.getElementById("missionGrid");
const toast = document.getElementById("toast");
const modal = document.getElementById("modalBackdrop");
const modalContent = document.getElementById("modalContent");

function save(){localStorage.setItem("nexusState",JSON.stringify(state))}
function format(n){return n.toLocaleString("pt-BR")}
function updateStats(){
  document.getElementById("xpValue").textContent=format(state.xp);
  document.getElementById("completedValue").textContent=state.completed;
  document.getElementById("streakValue").textContent=state.streak+" DIAS";
  const level = Math.max(1, Math.floor(state.xp/700)+1);
  document.getElementById("levelValue").textContent=level;
  const next = (level)*700;
  document.getElementById("nextXp").textContent=format(next);
  document.getElementById("xpBar").style.width=Math.min(100,(state.xp/(next))*100)+"%";
}
function showToast(msg){toast.textContent=msg;toast.classList.add("show");clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>toast.classList.remove("show"),2600)}

function render(filter="all"){
  const list=filter==="all"?missions:missions.filter(m=>m.cat===filter);
  grid.innerHTML=list.map(m=>`
    <article class="mission">
      <div class="mission-top"><span class="tag">${m.tag}</span><span class="difficulty">${m.diff}</span></div>
      <h3>${m.icon} ${m.title}</h3><p>${m.desc}</p>
      <div class="mission-meta">
        <div><span>RECOMPENSA</span><b>+${format(m.xp)} XP</b></div>
        <div><span>PRAZO</span><b>${m.time}</b></div>
        <button class="mission-action" onclick="openMission(${m.id})" aria-label="Ver missão">→</button>
      </div>
    </article>`).join("");
}
function renderLeaders(){
 document.getElementById("leaderboard").innerHTML=leaders.map((l,i)=>`
 <div class="leader"><span class="pos">${l[0]}</span><span class="leader-avatar">${l[3]}</span><div class="leader-info"><b>${l[1]}</b><span>${i===4?"VOCÊ":"AGENTE NEXUS"}</span></div><b class="leader-xp">${l[2]}</b></div>`).join("");
}
window.openMission=function(id){
 const m=missions.find(x=>x.id===id);
 modalContent.innerHTML=`<span class="modal-tag">${m.tag} • ${m.diff}</span><h3>${m.icon} ${m.title}</h3><p>${m.desc}</p>
 <div class="modal-info"><div><span>RECOMPENSA</span><b>+${format(m.xp)} XP</b></div><div><span>PRAZO</span><b>${m.time}</b></div></div>
 <button class="btn primary wide" onclick="acceptMission(${m.id})">ACEITAR MISSÃO →</button>`;
 modal.classList.add("open");
}
window.acceptMission=function(id){
 const m=missions.find(x=>x.id===id);
 state.xp+=m.xp;state.completed+=1;save();updateStats();modal.classList.remove("open");
 showToast(`Missão concluída! +${format(m.xp)} XP adicionados ao seu perfil.`);
}
document.getElementById("modalClose").onclick=()=>modal.classList.remove("open");
modal.addEventListener("click",e=>{if(e.target===modal)modal.classList.remove("open")});
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{
 document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));btn.classList.add("active");render(btn.dataset.filter);
}));
document.getElementById("randomMissionBtn").onclick=()=>openMission(missions[Math.floor(Math.random()*missions.length)].id);
document.getElementById("dailyBtn").onclick=()=>{
 state.streak+=1;save();updateStats();showToast("Desafio do dia aceito! Sua sequência aumentou.");
};
document.getElementById("viewAllBtn").onclick=()=>{
 document.querySelector('[data-filter="all"]').click();document.getElementById("missoes").scrollIntoView({behavior:"smooth"});
};
document.getElementById("profileBtn").onclick=()=>{
 modalContent.innerHTML=`<span class="modal-tag">PERFIL DO AGENTE</span><h3>RANGER</h3><p>Explorador NEXUS • Nível ${document.getElementById("levelValue").textContent}</p>
 <div class="modal-info"><div><span>XP TOTAL</span><b>${format(state.xp)}</b></div><div><span>MISSÕES</span><b>${state.completed}</b></div><div><span>SEQUÊNCIA</span><b>${state.streak} DIAS</b></div></div>
 <button class="btn primary wide" onclick="modal.classList.remove('open')">FECHAR PERFIL</button>`;
 modal.classList.add("open");
};
render();renderLeaders();updateStats();
