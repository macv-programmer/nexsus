# NEXUS — Site fictício

Um site futurista de missões e desafios, feito apenas com HTML, CSS e JavaScript.

## Arquivos
- `index.html` — estrutura da página
- `style.css` — visual responsivo
- `script.js` — filtros, missões, XP, ranking, modal e armazenamento local

## Publicar grátis
O projeto é estático e pode ser publicado no GitHub Pages. Crie um repositório, envie os três arquivos e habilite Pages em **Settings → Pages**. O GitHub Pages publica sites estáticos diretamente de um repositório, sem hospedagem separada.

Documentação oficial: https://docs.github.com/pt/pages
